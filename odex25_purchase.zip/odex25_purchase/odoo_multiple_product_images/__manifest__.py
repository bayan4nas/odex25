# -*- coding: utf-8 -*-
{
    'name': "Multiple Images",
    'summary': """
        Multiple Images and Categories on Products""",
    'description': """
        Creates an image gallery section available on every product and also on the product templates.
    """,
    'author': "Expert Co Ltd",
    'website': "http://www.ex.com",
    'category': 'Odex25-Purchase/Odex25-Purchase',
    'license': 'AGPL-3',
    'version': '14.0.1.0.1',
    'depends': ['product', 'stock', 'mrp'],
    'data': [
        'security/ir.model.access.csv',
        'data/clean_orphans_images.xml',
        'views/assets.xml',
        'views/product_image_backend.xml',

    ]
}
