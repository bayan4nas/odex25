{
    'name': "Khwalid Vendor",
    'version': '14.0.1.0.0',
    'summary': """Khwalid Vendor""",
    'category': 'Purchase',
    'author': "Expert Co Ltd",
    'website': "http://www.ex.com",
    'category': 'Odex25-Purchase/Odex25-Purchase',
    'company': 'Expert Co. Ltd.',
    'depends': ['base','mail','contacts'],
    
    'data': [
        'security/ir.model.access.csv',
        'security/secuirty.xml',
        'data/res_partner_sequence.xml',
        'views/res_partner.xml',
        'wizard/messeage_wiz.xml',
    ],
    'installable': True,
    'application': False,
}
