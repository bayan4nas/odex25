from . import res_parnter
