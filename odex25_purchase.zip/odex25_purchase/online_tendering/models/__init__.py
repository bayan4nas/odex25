# -*- coding: utf-8 -*-

from . import res_models
from . import purchase_requsition
from . import onlline_tender_conf
from . import tender_application