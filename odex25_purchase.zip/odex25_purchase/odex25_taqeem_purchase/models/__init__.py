from . import purchase_request, budget_confirmation, res_partner, account_analytic_account, res_config_setting, \
    res_company
from . import competitive_purchase_attachment
