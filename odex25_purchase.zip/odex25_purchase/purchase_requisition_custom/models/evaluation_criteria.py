# # -*- coding: utf-8 -*-

# from odoo import models, fields, api

# class EvaluationCriteria(models.Model):
#     _name = 'evaluation.criteria'
#     _description = 'Rvaluatioin Creiteria'

#     active = fields.Boolean(string='active',default=True)
#     # vendor_type = fields.Many2one(comodel_name='vendor.type', string='Vendor Type')
#     name = fields.Char(string='Name')
#     # calculation_method = fields.Selection([
#     #     ('per', 'Percentage'),
#     #     ('points' , 'Points')
#     # ], string='calculation Method')
#     owner = fields.Selection([
#         ('account', 'Finance'),
#         ('purchase' , 'Purchase'),
#         ('stock' , 'Stock'),
#     ], string='Owner')
#     # value = fields.Float(string='Value')
    
    
    

    